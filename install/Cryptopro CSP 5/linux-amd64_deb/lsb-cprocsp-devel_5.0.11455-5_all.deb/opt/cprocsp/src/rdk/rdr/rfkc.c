/*
 * Copyright(C) 2008 ������ ���
 *
 * ���� ���� �������� ����������, ����������
 * �������������� �������� ������ ���.
 *
 * ����� ����� ����� ����� �� ����� ���� �����������,
 * ����������, ���������� �� ������ �����,
 * ������������ ��� �������������� ����� ��������,
 * ���������������, �������� �� ���� � ��� ��
 * ����� ������������ ������� ��� ����������������
 * ���������� ���������� � ��������� ������ ���.
 */

/*!
 * \file $RCSfile$
 * \version $Revision: 87822 $
 * \date $Date: 2013-04-08 18:12:28 +0400 (Пн, 08 апр 2013) $
 * \author $Author: borodin $
 * \brief ����������������� �������� ���.
 */

#include "rdr_prj.h"


DWORD rdr_crypt_simple_key_set_step1(
    TSupSysEContext *context, 
    TRdrFkcOrder masked_key, DWORD key_length, 
    TRdrFkcPoint* public_key, 
    TRdrFkcEllipticPointParam uiIDg, 
    char * oid,
    TKeyAlgType alg_type, 
    DWORD key_type, 
    BOOL is_able_dh,
    unsigned int alg_id, 
    DWORD permissions,
    int index
) 
{
    DWORD code;
    TReaderFkcKeySet ks;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    ks.alg_type = alg_type;
    ks.dfkc = masked_key;
    ks.public_key = public_key;
    ks.step = TSetKeyStep_first;
    ks.key_length = key_length;
    ks.group_id = uiIDg;
    ks.index = index;
    ks.key_type = key_type;
    ks.alg_id = alg_id;
    ks.is_able_dh = is_able_dh;
    ks.oid = oid;
    ks.permissions = permissions;

    code = supsys_call(context, READER_FUN_KEY_SET, &ks);

    return code;
}

DWORD rdr_crypt_simple_key_set_step2(
    TSupSysEContext *context, 
    TRdrFkcOrder mask, DWORD key_length,
    TRdrFkcPoint* public_key, 
    TRdrFkcEllipticPointParam uiIDg, 
    char * oid,
    TKeyAlgType alg_type, 
    DWORD key_type, 
    BOOL is_able_dh,
    unsigned int alg_id,
    DWORD permissions,
    int* index
) 
{
    DWORD code;
    TReaderFkcKeySet ks;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    ks.dfkc = mask;
    ks.step = TSetKeyStep_second;
    ks.key_length = key_length;
    ks.index = *index;
    ks.alg_type = alg_type;
    ks.public_key = public_key;
    ks.group_id = uiIDg;
    ks.key_type = key_type;
    ks.alg_id = alg_id;
    ks.is_able_dh = is_able_dh;
    ks.oid = oid;
    ks.permissions = permissions;

    code = supsys_call(context, READER_FUN_KEY_SET, &ks);
    if (code)
	return code;
    *index = ks.index;
    return ERROR_SUCCESS;
}

DWORD rdr_crypt_set_gost_2001(TSupSysEContext *context) {
    return supsys_call(context, READER_FUN_SET_2001, NULL);
}

DWORD rdr_crypt_get_public_key(TSupSysEContext *context, DWORD key_type, TRdrFkcPoint* public_key) {
    TReaderFkcPublicKeyGet kg;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    kg.key_type = key_type;
    kg.flags.alg_id = kg.flags.id_g = kg.flags.oid = kg.flags.is_able_dh = kg.flags.permissions = 0 ;
    kg.flags.value = 1;
    kg.value = public_key;
    kg.oid = NULL;
    return supsys_call(context, READER_FUN_PUBLIC_KEY, &kg);
}

DWORD rdr_crypt_get_able_dh(TSupSysEContext *context, DWORD key_type, BOOL * is_able_dh) 
{
    TReaderFkcPublicKeyGet kg;
    DWORD code;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    kg.key_type = key_type;
    kg.flags.alg_id = kg.flags.id_g = kg.flags.oid = kg.flags.value = kg.flags.permissions = 0;
    kg.flags.is_able_dh = 1;
    kg.value = NULL;
    kg.oid = NULL;
    kg.is_able_dh = FALSE;
    code = supsys_call(context, READER_FUN_PUBLIC_KEY, &kg);
    if (code)
	return code;
    *is_able_dh = kg.is_able_dh;
    return ERROR_SUCCESS;
}

DWORD rdr_crypt_get_public_key_param(TSupSysEContext *context, DWORD key_type, unsigned int * alg_id, TRdrFkcEllipticPointParam * idG) {
    TReaderFkcPublicKeyGet kg;
    DWORD code;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    kg.key_type = key_type;
    kg.flags.alg_id = kg.flags.id_g = 1;
    kg.flags.value = kg.flags.oid = kg.flags.is_able_dh = kg.flags.permissions = 0;
    kg.value = NULL;
    kg.oid = NULL;
    code = supsys_call(context, READER_FUN_PUBLIC_KEY, &kg);
    if (code) return code;
    *alg_id = kg.alg_id;
    *idG = kg.id_g;
    return ERROR_SUCCESS;
}

DWORD rdr_crypt_get_public_key_oid(TSupSysEContext *context, DWORD key_type, char * oid) 
{
    TReaderFkcPublicKeyGet kg;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    kg.key_type = key_type;
    kg.oid = oid;
    kg.flags.oid = 1;
    kg.flags.alg_id = kg.flags.id_g = kg.flags.value = kg.flags.is_able_dh = kg.flags.permissions = 0;
    kg.value = NULL;
    return supsys_call(context, READER_FUN_PUBLIC_KEY, &kg);
}

DWORD rdr_crypt_get_key_permissions(TSupSysEContext *context, DWORD key_type, DWORD * permissions)
{
    TReaderFkcPublicKeyGet kg;
    DWORD code;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    kg.key_type = key_type;
    kg.oid = NULL;
    kg.flags.permissions = 1;
    kg.flags.alg_id = kg.flags.id_g = kg.flags.value = kg.flags.is_able_dh = kg.flags.oid = 0;
    kg.value = NULL;
    kg.permissions = 0;
    code = supsys_call(context, READER_FUN_PUBLIC_KEY, &kg);
    if (code) 
	return code;
    *permissions = kg.permissions;
    return ERROR_SUCCESS;
}

DWORD rdr_crypt_agreement(
TSupSysEContext *context,
 int index,
 DWORD key_type,
 const TRdrFkcPoint *point_Qalpha,
 size_t coord_length,
 const TRdrFkcUKM ukm,
 size_t ukm_length, 
TRdrFkcOrder mask, 
size_t mask_length,
 TRdrFkcOrder key, 
size_t * key_length)
{
    TReaderAgreeInfo aI;
    DWORD err;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    aI.to_FKC.index = index;
    aI.to_FKC.Qb = (TRdrFkcPoint *)point_Qalpha;
    aI.to_FKC.Qb_coord_size = coord_length;
    aI.to_FKC.ukm = (TReaderFkcUKMPtr)ukm;
    aI.to_FKC.ukm_length = ukm_length;
    aI.to_FKC.mask = (TReaderFkcOrderPtr)mask;
    aI.to_FKC.mask_length = mask_length;
    aI.to_CSP.key = (TReaderFkcOrderPtr)key;
    aI.to_CSP.key_length = *key_length;    
    aI.key_type = key_type;

    err = supsys_call(context, READER_FUN_AGREEMENT_FULL, &aI);
    if (err)
	return err;
    *key_length = aI.to_CSP.key_length;
    return ERROR_SUCCESS;
}

DWORD rdr_crypt_simple_key_gen(
    TSupSysEContext *context, 
    TRdrFkcEllipticPointParam uiIDg, 
    char * oid,
    TKeyAlgType alg_type, 
    DWORD key_type, 
    BOOL is_able_dh,
    unsigned int alg_id, 
    const BYTE * add_random_data, DWORD random_length, DWORD permissions,
    int* index, 
    TRdrFkcPoint * pubKey
)
{
    DWORD err;
    TReaderFkcKeyGen kg;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    kg.public_key = pubKey;
    kg.group_id = uiIDg;
    kg.alg_type = alg_type;
    kg.index = *index;
    kg.key_type = key_type;
    kg.alg_id = alg_id;
    kg.is_able_dh = is_able_dh;
    kg.oid = oid;
    kg.add_random_data = add_random_data;
    kg.random_data_length = random_length;
    kg.permissions = permissions;

    err = supsys_call(context, READER_FUN_KEY_GEN, &kg);
    if (err)
	return err;
    *index = kg.index;
    return ERROR_SUCCESS;
}

DWORD rdr_set_provider_callbacks(const TSupSysEContext *context, TProvCallCtx car_ctx, const TCarrierCallbacks * callbacks)
{
    TReaderProviderInfo info;
    DWORD code = 0;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    if (!callbacks)
	return (DWORD)ERROR_INVALID_PARAMETER;
    info.callbacks = *callbacks;
    info.context = car_ctx;
    code = supsys_call(context, READER_FUN_PROVIDER_INFO, &info);
    return code;
}


/* ������� ��������� �������� ��������������� ���������� */
static DWORD rdr_get_algids(TSupSysEContext *context, BOOL forUserKey, TRdrLoginInfoType auth_type, TRdrFkcEllipticPointParam * algid_array, size_t * size_algid_array)
{
    DWORD code = 0;
    TReaderInfoAlgIds algid = { 0 };
    TRdrFkcEllipticPointParam * ar = NULL;
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    if (*size_algid_array)
    {
	ar = calloc(*size_algid_array, sizeof(TRdrFkcEllipticPointParam));
	if (!ar)
	{
	    code = (DWORD)NTE_NO_MEMORY;
	    goto done;
	}
    }

    algid.size = *size_algid_array;
    algid.algs = ar;
    algid.auth_type = auth_type;
    algid.forUserKey = forUserKey;

    code = supsys_call(context, READER_FUN_ALGID_INFO, &algid);
    if (code == ERROR_MORE_DATA)
    {
	*size_algid_array = algid.size;
	goto done;
    }
    else if (code)
	goto done;
    *size_algid_array = algid.size;
    if ((algid.size > 0) && algid_array != NULL && ar != NULL)
    {
	size_t i;
	for (i = 0; i < algid.size; i++)
	    algid_array[i] = ar[i];
    }
done:
    if (ar) free(ar);
    return code;
}

DWORD rdr_get_userkey_algids(TSupSysEContext *context, TRdrFkcEllipticPointParam * algid_array, size_t * size_algid_array)
{
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    return rdr_get_algids(context, TRUE, 0, algid_array, size_algid_array);
}

DWORD rdr_get_sespake_algids(TSupSysEContext *context, TRdrLoginInfoType auth_type, TRdrFkcEllipticPointParam * algid_array, size_t * size_algid_array)
{
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    return rdr_get_algids(context, FALSE, auth_type, algid_array, size_algid_array);
}

DWORD rdr_set_sm_state(TSupSysEContext *context, BOOL isSM, TRdrLoginInfoType auth_type)
{
    TReaderInfoSmState inf; 
    DbTrace(DB_CALL, (FTEXT(db_ctx, "(...)")));
    inf.isSM = isSM;
    inf.auth_type = auth_type;
    return supsys_call(context, READER_FUN_SET_SM_STATE, &inf);
}

/* end of file: $Id: rfkc.c 87822 2013-04-08 14:12:28Z borodin $ */
