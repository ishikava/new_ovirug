#set NLSPATH for out CSP
if [ -z "$NLSPATH" ];
then
    NLSPATH=/opt/cprocsp/share/locale/%L/LC_MESSAGES/%N
else
    NLSPATH=$NLSPATH:/opt/cprocsp/share/locale/%L/LC_MESSAGES/%N
fi
export NLSPATH
